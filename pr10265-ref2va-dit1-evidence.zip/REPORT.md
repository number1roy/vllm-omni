# #10265 one-step DiT probe

### One-step DiT follow-up (performance probe)

Only `num_inference_steps` changed from 4 to 1. Same frozen candidate, Ref2VA case, cards 8–15, ordinary LO (DLO disabled), quantization, USP8 and output settings. One serial OFF→ON→OFF window, one warm-up plus five hot requests per arm, 2026-11-28 12:13–12:34 UTC+08:00.

| Arm | HTTP mean ± sample SD (s) | Denoise (s) | Reference encoding (s) | Peak API memory (MB) |
| --- | ---: | ---: | ---: | ---: |
| a1-off | 28.283 ± 0.092 | 14.218 | 1.826 | 18,436 |
| b-on | 26.448 ± 0.217 | 14.501 | 1.143 | 19,306 |
| a2-off | 28.484 ± 0.151 | 14.420 | 1.806 | 18,436 |

Bracketed OFF 28.383 s versus ON 26.448 s; signed latency saving +1.936 s (+6.82%); noise estimate 0.201 s (max of OFF drift and OFF SDs), saving/noise 9.64. The one-step probe observed 1.936 s (6.82%) lower HTTP latency in this window. This is one window; it does not establish cross-window stability or change the four-step repeatability verdict.

Stage savings (positive = ON faster): denoise -0.182 s, reference encoding +0.673 s, text encoding +0.093 s, audio decode -0.001 s, uninstrumented generation remainder +1.348 s. The remainder includes video decoding/encoding and other pipeline work; it is not an isolated decoder measurement.

All 18 requests returned HTTP 200 and passed native shape/frame/audio checks. Progress logs verified `1/1` for each request; startup and all three warm-ups are excluded. This one-step run is a timing probe, not a validated replacement for four-step generation quality or an end-to-end losslessness claim. Full local results are retained; public evidence excludes the case inputs and all media.

## Version and reproduction

Measured base `dda822f4a7e1839b34abc09a2cbb4dbee07ee7eb`, local parent `c1d928f60740c4a05e32df441bc85b48f6b17be4`, full main-relative patch SHA-256 `2acf45caf4bf62f75841d7062e6e7e7c45b847b8435dae740ee7a256547208a9`. The source branch of the public PR remains `1fc2d461ebc315ec41404a0f85669315a6869abf`; this probe measures the local rebased candidate. Runtime: CANN 9.3.0, host driver 25.5.0, PyTorch 2.10.0+cpu, TorchNPU 2.10.0.post7, vLLM 0.34.0. Native workload: 736×1280, 294 frames, 24 fps, 12.25 s, seed 42, Ref2VA, DiT INT8, TORCH_SDPA, tiled VAE, ordinary LO, USP8, concurrency one. Same synchronized pipeline stage timer in all arms, no operator trace collection.

Use the reproduction procedure and patch in the [frozen four-step evidence bundle](https://github.com/number1roy/vllm-omni/raw/02810ef093b5000c82c8ba5db661c93dcc899a8c/pr10265-ref2va-repeatability-evidence.zip) with only `num_inference_steps=1`, and 1 warm-up + 5 measured requests for each OFF/ON/OFF arm. Same local references and prompt are required; the archive cannot recreate the exact case without these external inputs. No fixed-latent replay was rerun for this probe.

AI assistance: TRAE CLI prepared the probe, checked actual NPU measurements and drafted the report.
