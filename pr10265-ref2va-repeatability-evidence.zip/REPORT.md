# #10265 Ref2VA evidence

## Ref2VA performance and repeatability (rebased follow-up candidate)

The measured base is `dda822f4a7e1839b34abc09a2cbb4dbee07ee7eb`. The local rebased candidate is parent `c1d928f60740c4a05e32df441bc85b48f6b17be4` plus the frozen main-relative candidate diff in the evidence (full main-relative SHA-256 `2acf45caf4bf62f75841d7062e6e7e7c45b847b8435dae740ee7a256547208a9`). **These are follow-up results on that exact candidate, not validation of the published PR head `1fc2d461ebc315ec41404a0f85669315a6869abf`.** The candidate's `--additional-config '{"component_cache_reuse":true}'` is opt-in and defaults to `false`.

MiniMax-H3 Ref2VA; 8× Ascend 910B4-1, CANN 9.3.0, driver 25.5.0, PyTorch 2.10.0+cpu, TorchNPU 2.10.0.post7, vLLM 0.34.0; same fixed input, seed 42, 4 denoise steps, native 736×1280, 24 fps, 294 frames/12.25 s; USP8, tiled VAE, ordinary layerwise offload, TORCH_SDPA and DiT INT8. Concurrency was one. Client timings include response download, not startup, warm-up, or delivery crop. Synchronized pipeline stage timers were on in all HTTP arms; no operator trace was collected.

### HTTP follow-up: two independent OFF → ON → OFF windows

Both windows used the same eight cards (8–15), a fresh service per arm, one warm-up and five timed hot requests per arm. The card group was released for at least ten minutes between windows. The bracketed OFF mean is the average of the two OFF arm means. Each noise estimate is the maximum of the OFF-to-OFF mean drift and the two OFF within-arm sample SDs. Timings are compared within windows, not by pooling elapsed times across windows.

| Window (UTC+08:00) | A1 OFF mean ± SD | B ON mean ± SD | A2 OFF mean ± SD | Bracketed OFF | Gain | Control noise |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| W1 (2026-11-28 00:08–00:42) | 73.109 ± 1.001 | 73.213 ± 1.295 | 72.222 ± 0.656 | 72.665 | -0.547 s (-0.75%) | 1.001 s |
| W2 (2026-11-28 00:52–01:26) | 74.845 ± 2.479 | 70.842 ± 1.785 | 72.347 ± 0.502 | 73.596 | +2.753 s (+3.74%) | 2.498 s |

Times are in seconds. Positive gain means lower latency with reuse. **The follow-up does not establish a repeatable end-to-end latency gain.** W1 did not exceed the corresponding control noise floor. The separate fixed-latent decoder result below is unaffected.

All 36 follow-up requests returned HTTP 200 and passed response size and format checks; 30 hot observations entered the performance summary. Server-side stage evidence:

| Window | Generation saved (s) | Reference encode saved (s) | Denoise saved (s) | Audio decode saved (s) | Peak API memory, OFF → ON (MB) |
| --- | ---: | ---: | ---: | ---: | ---: |
| W1 | -0.582 | +0.670 | -2.617 | +0.000 | 18,520 → 19,388 |
| W2 | +2.751 | +0.718 | +0.570 | +0.001 | 18,520 → 19,388 |

The stage headers do not isolate video decoder offload. The initial HTTP window on a different set of eight cards (0–7) observed 70.488 → 68.337 s (3.05% lower); it is context, not part of the two-window gate.

### Fixed-latent decoder and correctness

In the earlier standalone eight-rank decoder ablation (3 warm-ups, 5 hot iterations per arm), the bracketed staged load/decode/offload time improved **11.679 → 9.993 s (14.43% lower)**. Video decoder offload was the largest phase reduction (1.17 s); ON had zero steady-state purge calls on every rank. Peak reserved memory after offload increased from 0.043 to 17.514 GiB. These results exclude DiT and output encoding and do not represent a throughput or bounded-owner DLO result. Pre-codec results were bitwise equal on the fixed latent pair; the HTTP runs do not establish end-to-end bitwise equality.

The evidence includes per-request times, HTTP status and byte counts, server timing lines, memory, aggregate correctness, source fingerprint, and reproduction commands. The input case and all media artifacts are excluded. The earlier targeted suite passed 89 tests on the same source fingerprint; no full CI run is claimed here.

AI assistance: TRAE CLI ran the controlled benchmarks, verified evidence and drafted this report. Timings are actual NPU measurements.

## Reproduction procedure

Use the same installed NPU runtime, the patched worktree, and your own local Ref2VA case. Use identical reference images, prompt and request parameters for each arm. The original input case and captured decoder input are not included, so the exact timings cannot be regenerated from this ZIP alone.

Launch the server for each arm with `REUSE` set to `false`, `true`, then `false`, stopping each owned service before the next arm:

```sh
ASCEND_RT_VISIBLE_DEVICES=8,9,10,11,12,13,14,15 VLLM_WORKER_MULTIPROC_METHOD=spawn \
  HF_HUB_OFFLINE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  python -m vllm_omni.entrypoints.cli.main serve "$MODEL_DIR" --omni \
  --trust-remote-code --host 127.0.0.1 --port "$PORT" --served-model-name "$MODEL_NAME" \
  --task-type ref2va --num-gpus 8 --usp 8 --ring 1 --text-encoder-tp-size 8 \
  --vae-parallel-mode tile --vae-use-tiling --vae-patch-parallel-size 8 \
  --enable-layerwise-offload --enforce-eager --enable-diffusion-pipeline-profiler \
  --diffusion-attention-backend TORCH_SDPA \
  --diffusion-quantization-config '{"transformer":{"method":"int8"}}' \
  --additional-config "{\"component_cache_reuse\":$REUSE}"
```

After `/v1/models` identifies the expected model, send one warm-up and five serial measured requests per arm. For example, with local paths supplied by the operator:

```sh
curl -sS --max-time 1200 -D "$HEADERS" -o "$RESPONSE" \
  -w '%{http_code}\t%{time_total}\t%{size_download}\n' \
  "http://127.0.0.1:$PORT/v1/videos/sync" \
  --form-string "model=$MODEL_NAME" --form-string "prompt=$PROMPT" \
  --form-string width=736 --form-string height=1280 --form-string fps=24 \
  --form-string num_inference_steps=4 --form-string flow_shift=12.0 --form-string seed=42 \
  --form-string 'extra_params={"task":"ref2va","duration":12.25,"aspect_ratio":"9:16","audio_flow_shift":3.0,"preencode_mp4":true,"video_codec_options":{"preset":"ultrafast","threads":"4"}}' \
  -F "input_references=@$REF_1" -F "input_references=@$REF_2" \
  -F "input_references=@$REF_3" -F "input_references=@$BACKGROUND"
```

For the decoder replay, prepend the package's `reproduce/capture` directory to `PYTHONPATH` for the first service only and set `LBW_BEACH_CAPTURE` to an absent local file. Do not time the request that records this input. Use the resulting file as `LATENT_PAIR`:

```sh
ASCEND_RT_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 HF_HUB_OFFLINE=1 \
  OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 H3_VIDEO_DECODER_FUSED_INFER_ATTENTION=0 \
  H3_VIDEO_DECODER_CROSS_CHUNK=0 H3_VAE_OPERATOR_FIR_C16_INSTALL=0 \
  python -m torch.distributed.run --standalone --nproc_per_node=8 \
  reproduce/lifecycle.py --arm aba --model "$MODEL_DIR" --inputs "$LATENT_PAIR" \
  --output-dir "$BENCH_DIR" --warmups 3 --formals 5 --precision
```

`repeatability-timing.json` and `repeatability-server-timing.log` contain the new windows; `initial/` contains the earlier HTTP window. `decoder-timing.json` and `decoder-rank-samples.json` contain the standalone fixed-latent ablation. The archived ZIP cannot reproduce the original workload without external local inputs.
