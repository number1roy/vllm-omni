"""Capture the decoder input once, on A1's excluded warm-up request."""

from functools import wraps
from importlib.abc import MetaPathFinder
from importlib.machinery import PathFinder
from pathlib import Path
import os
import sys

CAPTURE = Path(os.environ["LBW_BEACH_CAPTURE"])
TARGET = "vllm_omni.diffusion.models.minimax_h3.pipeline_minimax_h3"


class CaptureFinder(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname != TARGET:
            return None
        spec = PathFinder.find_spec(fullname, path, target)
        if spec is None:
            return None
        original_exec = spec.loader.exec_module

        def exec_module(module):
            original_exec(module)
            original_decode = module.MiniMaxH3Pipeline.decode_to_mp4

            @wraps(original_decode)
            def capture(pipeline, video_latent, audio_latent, *args, **kwargs):
                import torch
                import torch.distributed as dist

                if (not dist.is_initialized() or dist.get_rank() == 0) and not CAPTURE.exists():
                    tmp = CAPTURE.with_suffix(".partial")
                    torch.save((video_latent.detach().cpu(), audio_latent.detach().cpu()), tmp)
                    tmp.replace(CAPTURE)
                return original_decode(pipeline, video_latent, audio_latent, *args, **kwargs)

            module.MiniMaxH3Pipeline.decode_to_mp4 = capture

        spec.loader.exec_module = exec_module
        return spec


sys.meta_path.insert(0, CaptureFinder())
